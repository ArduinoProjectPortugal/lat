import ClientSlider3 from "../component/clientSlider-3.js";

function Clients3() {
    return (
        <>
            
            {/* <!-- Clients Logo --> */}
            <div className="p-tb50 bg-gray">
                <div className="container">
                    <div className="clients-carousel owl-none owl-carousel">
                        <ClientSlider3/>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Clients3;
